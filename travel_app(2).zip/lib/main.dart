import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:travel_app/pages/frist_page.dart';
import 'package:travel_app/pages/bookmark.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: "AIzaSyB_-TNcex9OrrvgGlZnKw8EMtzj7jHOMzw",
      appId: "1:61829779662:android:66f512273cd3d2415e009f",
      messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
      projectId: "travelapp-88d85",
    ),
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Travel App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: GoogleFonts.mulishTextTheme(
          Theme.of(context).textTheme,
        ),
      ),
      home: const LandingPage(),
    );
  }
}

class DatabaseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> addFlightBooking(String name, String place, String date) async {
    try {
      await _db.collection('flight_bookings').add({
        'name': name,
        'place': place,
        'date': date,
      });
    } catch (e) {
      print('Error adding flight booking: $e');
    }
  }
}
